/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package equipo2_proyecto2;
import java.util.Scanner;

public class Equipo2_proyecto2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int dec=0;
        Decicion(dec);
    }
    
    public static void Decicion(int dec){
        Scanner lector = new Scanner(System.in);
        System.out.println("Elije el metodo (0 balanceo de ámbitos / 1 Resolucion de expreciones postfijas)");
        dec = lector.nextInt();
        switch(dec){
            case 0:
                String can;
                System.out.println("Ingrese la cadena de caracteres");
                can=lector.next();
                BalanceoAmbitos ba = new BalanceoAmbitos(can);
                ba.equilibrio();
                break;
                
            case 1:
                String nums;
                System.out.println("Ingrese la cadena de datos");
                nums = lector.next();
                ExpPos x = new ExpPos(nums);
                x.Post();
                break;
                
        }
    }
}
