/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package equipo2_proyecto2;

import java.util.Stack;

/**
 *
 * @author danie
 */
public class BalanceoAmbitos {
    public String caracteres;
    public Stack<Character> cadena= new Stack<Character>();
    
    BalanceoAmbitos(String c){
        this.caracteres = c;
    }
    
    public void equilibrio(){
        char[] carac = caracteres.toCharArray();
        int cont=0;
        for (int i = 0; i < carac.length; i++) {
            if (carac[i]=='(') {
                cadena.push('(');
                cont++;
            }
            else if (carac[i]=='[') {
                cadena.push('[');
                cont++;
            }
            else if (carac[i]=='{') {
                cadena.push('{');
                cont++;
            }
            else if (carac[i]==')'){
                if (!cadena.empty()) {
                    cadena.pop();
                    cont--;
                }
            }
            else if (carac[i]==']'){
            if (!cadena.empty()) {
                    cadena.pop();
                    cont--;
                }
            }
            else if (carac[i]=='}'){
                if (!cadena.empty()) {
                    cadena.pop();
                    cont--;
                }
            }
            
        }
        if (cont==0) {
                System.out.println("True");
            }
        else{
            System.out.println("False");
        }
    }
    
}
