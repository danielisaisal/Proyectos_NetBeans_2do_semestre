/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package equipo2_proyecto2;
import java.util.Stack;
/**
 *
 * @author danie
 */
public class ExpPos {
    public String expr;
    public String[] post;
    Stack <String> E = new Stack <String>();
    Stack <String> P = new Stack <String>();
    
    ExpPos(String p){
        this.expr = p;
         
    }
    
    public void Post(){
        post = expr.split("");
        for (int i = post.length-1; i >= 0; i--) {
            E.push(post[i]);
        }
        
        String operador = "+-*/%";
        while(!E.isEmpty()){
            if (operador.contains(""+E.peek())) {
                P.push(evaluar(E.pop(),P.pop(), P.pop()) + "");
            }
            else{
                P.push(E.pop());
            }
        
        }
        System.out.println("Exprecion: " + this.expr);
        System.out.println("Resultado: " + P.peek());
    
    }
    
    public int evaluar(String op, String n2, String n1){
        int num1 = Integer.parseInt(n1);
        int num2 = Integer.parseInt(n2);
        if (op.equals("+")) {
            return (num1 + num2);
        }
        else if (op.equals("-")) {
            return (num1 - num2);
        }
        else if (op.equals("*")) {
            return (num1 * num2);
        }
        else if (op.equals("/")) {
            return (num1 / num2);
        }
        else if (op.equals("%")) {
            return (num1 % num2);
        }
        return 0;
    }
    
}
