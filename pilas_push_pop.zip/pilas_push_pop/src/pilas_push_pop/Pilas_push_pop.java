/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilas_push_pop;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class Pilas_push_pop {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada=new Scanner(System.in);
        int n;
        n = entrada.nextInt();
        Pila pil=new Pila(n);
        pil.push("hugo");
        pil.push("paco");
        pil.push("Luis");
        System.out.println(""+pil.pop());
        System.out.println(""+pil.pop());
        System.out.println(""+pil.pop());
        System.out.println(""+pil.pop());
    }
    
}
