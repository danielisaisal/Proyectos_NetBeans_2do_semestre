/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilas_push_pop;

/**
 *
 * @author danie
 */
public class Pila {
    public String[] nombre;
    public int tope;
    
    Pila(int n){
        this.nombre=new String[n];
        this.tope=-1;
    
    }
    
    public void push(String nuevo){
        if (tope<nombre.length-1) {
            tope++;
            nombre[tope]=nuevo;
        }else{
            System.out.println("No es posible realizar el metodo");
        }
    
    }
    
    public String pop(){
        if (tope>=0) {
            return nombre[tope--];
        }
        else{
            System.out.println("No es posible eliminar algo del arreglo si no tiene nada");
            return null;
        }
    }
}
