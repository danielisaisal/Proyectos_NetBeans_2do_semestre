/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package srdi_fibonachi;
import java.util.Scanner;
/**
 *
 * @author danie
 */
public class SRDI_Fibonachi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int num, res=0;
        System.out.println("Ponga el limite de fibonachi: ");
        num = entrada.nextInt();
        
        res=fibonachi(num);
        System.out.println(res);
    }
    
    public static int fibonachi(int n){
        if (n>1) {
            return fibonachi(n-1)+fibonachi(n-2);
        }
        else if (n==1) {
            return 1;
        }
        else if (n==0){
            return 0;
        }
        else
            return 0;
    }
}
