/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cola_de_objetos;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class Cola_de_objetos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Metodos();
    }
    
    public static void Metodos(){
        Scanner entrada = new Scanner(System.in);
        
        int n, decN, decw, años, matricula;
        String datos;
        System.out.println("Ingrese el limite del arreglo");
        n = entrada.nextInt();
        ColaCircular cc = new ColaCircular (n);
        do{
            System.out.println("Que quiere hacer (0.Insertar / 1.Eliminar)");
            decN = entrada.nextInt();
            switch(decN){
                case 0:
                    System.out.println("Ingrese el nombre del Alumno");
                    datos = entrada.next();
                    System.out.println("Ingrese los años del alumno");
                    años = entrada.nextInt();
                    System.out.println("Ingrese la matricula del Alumno");
                    matricula = entrada.nextInt();
                    cc.Insertar(datos, años, matricula);
                    System.out.println("Alumno ingresado: " + datos + "  Matricula: " + matricula + "  Edad: " + años);
                    System.out.println("Frente: " + cc.fr + "   Final:" + cc.fi);
                    break;
                case 1:
                    cc.Eliminar();
                    System.out.println("Frente: " + cc.fr + "   Final:" + cc.fi);
                    break;
            }
            System.out.println("¿Quiere terminar el proceso? (0.no / 1.si)");
            decw = entrada.nextInt();
        }while(decw !=1);
    }
    
}
