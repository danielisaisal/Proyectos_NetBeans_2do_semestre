/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cola_de_objetos;

/**
 *
 * @author danie
 */
public class ColaCircular {
    public int fr;
    public int fi;
    public String temp;
    public Alumnos[] cadena;
    
    ColaCircular(int n){
    this.cadena = new Alumnos[n];
    this.fr=-1;
    this.fi=-1;
    }
    
    public void Insertar(String nuevo, int ed, int matri){
        if((fi==cadena.length-1) && (fr==0) || (fi+1)==fr) {
            System.out.println("Desbordamiento");
        }
        else{
            if (fi==cadena.length-1) {
                fi=0;
            }
            else{
                fi+=1;
            }
            cadena[fi]=new Alumnos(ed, nuevo, matri);
            if (fr==-1) {
                fr=0;
            }
        }
    }
    
    public Alumnos Eliminar(){
        //String temp = "";
        Alumnos temp=null;
        if (fr == -1) {
            System.out.println("Subdesbordamiento");
        }
        else{
            temp=cadena[fr];
            System.out.println("Alumno eliminado: " + cadena[fr].nombre + "  Matricula: " + cadena[fr].matricula + "  Edad: "+ cadena[fr].edad);
            if (fr == fi) {
                fr = -1;
                fi = -1;
            }
            else{
                if (fr==cadena.length-1) {
                    fr = 0;
                    
                }
                else{
                    fr += 1;
                }
            }
            
        }
        return temp;
    }
}
