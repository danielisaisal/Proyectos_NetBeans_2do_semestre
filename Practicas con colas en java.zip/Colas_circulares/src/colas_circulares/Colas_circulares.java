/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colas_circulares;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class Colas_circulares {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int n;
        n = entrada.nextInt();
        ColasCirculares col = new ColasCirculares(n);
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.Insertar("Memo");
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.Insertar("Carlos");
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.Insertar("Samanta");
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.Eliminar();
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.Insertar("Casandra");
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);

    }

}
