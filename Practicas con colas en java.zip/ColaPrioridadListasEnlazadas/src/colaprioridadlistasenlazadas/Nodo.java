/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colaprioridadlistasenlazadas;

/**
 *
 * @author danie
 */
public class Nodo { // Acceso y nombre de la clase
    public Maestro p; // Objeto de tipo Maestro
    public Nodo sig; //Objeto de tipo Nodo del objeto siguiente
    public Nodo ant; //Objeto de tipo Nodo del objeto anterior

    public Nodo(Maestro p) { //Constructor
        this.p = p; //Dandole valor a variable p
        this.sig = null; //Dandole valor a variable sig
        this.ant = null; //Dandole valor a variable ant
    }

    public Nodo() { //constructor vacio
    }
    
    
    
}
