/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colaprioridadlistasenlazadas;
import java.util.Scanner; //Se importa un escaner
/**
 *
 * @author danie
 */
public class ColaPrioridadListasEnlazadas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Menu(); //Metodo de valor
    }
    
    
    public static void Menu(){ //Metodo llamado menu
        Scanner entrada = new Scanner(System.in); //Scanner
        int n, decN, decw, prio; //dar de alta datos de tipo entero
        String nom, pade, numSeg; //dar de alta datos de tipo string
        Lista l=new Lista(); //objeto de tipo lista
        do{ //inicio del ciclo
            System.out.println("Que quiere hacer (1.Nvo paciente / 2.Atender)"); //imprecion de deciciones
            decN = entrada.nextInt(); //toma el dato de decicion
            switch(decN){ //decicion
                case 1: // caso 1                  
                    l.insertar(leerDatos());//Llamar al metodo de insertar
                    l.ImprimirLista();//Llamar al metodo de imprimir la lista
                    break; //cierra el switch
                case 2: //caso 2
                    l.eliminar(); //Llamar el metodo para eliminar
                    l.ImprimirLista(); //Llamar al metodo de imprimir la lista
                    //l.ImprimirLista(); //se manda a llamar el metodo de imprecion de la clase lista
                    break; //cierra el switch
            }
            System.out.println("¿Quiere terminar el proceso? (0.no / 1.si)"); //imprecion de mensaje
            decw = entrada.nextInt(); //toma el dato de decicion
        }while(decw !=1);//condicion del ciclo
    }  
    
    
    public static Maestro leerDatos(){ //Metodo para lerdatos de tipo maestro
        Scanner entrada = new Scanner(System.in); //Scanner
        String decEmb; //variable de tipo string
        Maestro aux = new Maestro(); //objeto de tipo maestro
        System.out.println("Ingrese el nombre del maestro"); // Imprecion de pantalla
        aux.nombreM = entrada.next(); //Tomar el dato de nombre
        System.out.println("Sexo (H/M)"); //Imprecion de pantalla
        aux.sexo = entrada.next(); //Tomar el dato del sexo
        if ("H".equals(aux.sexo)) { //Condicion que evalua si el sexo es H
            aux.embar = null; //La variable de embaraso se queda nula
        }
        else if("M".equals(aux.sexo)){ //Condicion que evalua si el sexo es M
            System.out.println("¿Esta embarazada? S/N"); //Imprecion de pantalla
            decEmb = entrada.next(); //Se le da valor a la decicion del embaraso
            if ("S".equals(decEmb)) { //Condicion que evalua la decicion si se respondio S
                aux.embar = "S"; //La variable de embarazo toma el valor de S
            }
            else{
                aux.embar = "N"; //La variable de embarazo toma el valor de N
            }
        }
        System.out.println("CURP"); //Imprecion de pantalla
        aux.CURP = entrada.next(); //se le da valor al curp
        System.out.println("Edad"); //Imprecion de pantalla
        aux.edad = entrada.nextInt(); //se le da valor a la edad
        System.out.println("Nivel (ejemplo: 1.basico, 2.media-superior, 3.superior)"); //Imprecion de pantalla
        aux.Nivel = entrada.nextInt(); //se le da valor al nivel
        System.out.println("Escuela de procedencia"); //Imprecion de pantalla
        aux.Escuela = entrada.next(); //se le da valor a la escuela
        return aux; //retorna el auxiliar
    }
    
    
}
