/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colaprioridadlistasenlazadas;

/**
 *
 * @author danie
 */
public class Maestro {
    public String CURP; //Variable de tipo string
    public String nombreM; //Variable de tipo string
    public int edad; //Variable de tipo int
    public String Escuela; //Variable de tipo string
    public int Nivel; //Variable de tipo int
    public String sexo; //Variable de tipo string
    public int prioridad; //Variable de tipo int
    public String embar; //Variable de tipo string
    
    
    public Maestro(String curp, String nom, int ed, String escu, int nivel, String sex){ //Constructor de la clase maestro
        this.CURP = curp; //Se le da valor al Curp
        this.edad = ed; //Se le da valor a la edad
        this.Escuela = escu; //Se le da valor a la escuela
        this.Nivel = nivel; //Se le da valor al nivel
        this.nombreM = nom; //Se le da valor al nombre
        this.sexo = sex; //Se le da valor al sexo
    }

    public Maestro() { //Constructor vacio
    }
    
    public void Calculo(){ // Metodo de calculo de prioridad
        this.prioridad=0; //Se inicializa la prioridad en 0
        if (this.edad >= 50) { //condicional donde se evalua si la edad es mayor igual a 50
            this.prioridad += 3; //la prioridad se le suma 3
        }
        if ("M".equals(this.sexo)) { //Condicional donde se evalua si el Sexo tiene como dato M
            if ("S".equals(this.embar)) { //Condicional donde se evalua si la persona esta embarazada
                this.prioridad+=2; //a la prioridad se le suma 2
                //en el main preguntar si es hombre o mujer y preguntar si esta embarazada en caso de que sea mujer
            }
        }
        if (this.Nivel == 1) { //El nivel toma el valor de 1
            this.prioridad+=1; // a la prioridad se le suma 1
        }
        
    }

}
