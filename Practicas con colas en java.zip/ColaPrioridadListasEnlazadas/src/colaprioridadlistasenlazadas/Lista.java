/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colaprioridadlistasenlazadas;

/**
 *
 * @author danie
 */

    
public class Lista { //Creacion de la clase
    Nodo inicio = null; //Objeto de tipo Nodo
    Nodo aux = null; //Objeto de tipo Nodo

    public void insertar(Maestro n){ //Metodo para insertar
        Nodo nuevo = new Nodo(n); //Objeto de tipo nodo
        if (inicio == null) { //condicional donde se evalua si el inicio es nulo
            inicio = nuevo; //El inicio toma el valor del nuevo
            n.Calculo(); //se calcula la prioridad
        }
        else{
            if (inicio != null) { // Concicional si el inicio es diferente a nulo
                aux = inicio; //el auxiliar toma el valor del inicio
                while(aux.sig !=null && aux.ant !=null && aux.ant.p.prioridad >= aux.sig.p.prioridad){ //ciclo donde se evalua si el auxiliar siguiente y anterior sean nulos
                    aux.ant = aux; // el auxiliar anterior toma el valor del auxiiar
                    aux = aux.sig; // el auxiliar toma el valor del auxiliar siguiente
                }
                n.Calculo(); //se calcula la prioridad
                if (nuevo.p.prioridad > inicio.p.prioridad) { //Condicional donde se evalua si la prioridad del nuevo es mayor a la prioridad del inicio
                    nuevo.sig = inicio; //el objeto nuevo toma el valor del inicio
                    inicio = nuevo; //el inicio toma el valor del nuevo
                }
                else if (nuevo.p.prioridad <= inicio.p.prioridad && nuevo.p.prioridad > aux.sig.p.prioridad) { //condicional donde se evaluia si la prioridad es menor o igual a la prioridad del inicio y si la prioridad del nuevo es mayor al auxiliar siguiente
                    nuevo.sig = aux.sig; //el objeto nuevo siguiente toma el valor del auxiliar siguiente
                    aux.sig = nuevo; //el auxiliar siguiente toma el valor del objeto nuevo
                }
                else{
                    aux.sig = nuevo; //el auxiliar siguiente toma el valor del objeto nuevo
                }
            }    
        }
    }
    
    public Nodo eliminar(){ //Metodo para eliminar objetos en la lista
        aux = inicio; //El auxiliar toma el valor del inicio
        
        if (inicio == null) { //Condicional donde se evalua si el inicio es igual a nulo
            System.out.println("Lista enlazada vacia"); //imprecion de pantalla
        }
        else{ 
           inicio=inicio.sig; //el inicio toma el valor del siguiente inicio
           
        }
        Nodo eliminado=inicio; //objeto de tipo nodo cuyo valor es el inicio
        return eliminado; //se retorna el objeto eliminado
    
    }
    
    public void ImprimirLista(){ //Metodo de imprecion de lista
        aux=inicio; // el auxiliar se le da el valor del inicio
        System.out.println("CURP ||\t" + "Nombre ||\t" + "Nivel ||" + "\t" + "Sexo ||\t" + "Prioridad"); //imprecion de campos
        while(aux.sig !=null){ //ciclo donde se evalua el auxiliar siguiente sea diferente igual a nulo
            System.out.println(aux.p.CURP + "||\t" + aux.p.nombreM + "" + "||\t" + aux.p.Nivel + "||\t" + aux.p.sexo + "||\t" + aux.p.prioridad); //se imprimen los datos de la lista
            aux = aux.sig; //el auxiliar toma el valor del siguiente
        }
        System.out.println(aux.p.CURP + "||\t" + aux.p.nombreM + "||\t" + aux.p.Nivel + "||\t" + aux.p.sexo + "||\t" + aux.p.prioridad);
    }
    
}
