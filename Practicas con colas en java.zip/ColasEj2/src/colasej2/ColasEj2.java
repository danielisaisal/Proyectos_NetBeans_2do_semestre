/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colasej2;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class ColasEj2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ColasEj2Class col = new ColasEj2Class(6);
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.Insertar("AA");
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.Insertar("BB");
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.Insertar("CC");
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        System.out.println("Elemento Eliminado: "+col.Eliminar());
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.Insertar("DD");
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.Insertar("EE");
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.Insertar("FF");
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.Insertar("GG");
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.Insertar("HH");
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        System.out.println("Elemento Eliminado: "+col.Eliminar());
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        System.out.println("Elemento Eliminado: "+col.Eliminar());
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
    
    }
    
}
