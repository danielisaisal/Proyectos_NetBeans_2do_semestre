/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colasej2;

/**
 *
 * @author danie
 */
public class ColasEj2Class {
    public int fr;
    public int fi;
    public String temp;
    public String[] cadena;
    
    ColasEj2Class(int n){
    this.cadena = new String[n];
    this.fr=-1;
    this.fi=-1;
    }
    
    public void Insertar(String nuevo){
        if((fi==cadena.length-1) && (fr==0) || (fi+1)==fr) {
            System.out.println("Desbordamiento");
        }
        else{
            if (fi==cadena.length-1) {
                fi=0;
            }
            else{
                fi+=1;
            }
            cadena[fi]=nuevo;
            if (fr==-1) {
                fr=0;
            }
        }
    }
    
    public String Eliminar(){
        String temp = "";
        if (fr == -1) {
            System.out.println("Subdesbordamiento");
        }
        else{
            temp=cadena[fr];
            if (fr == fi) {
                fr = -1;
                fi = -1;
            }
            else{
                if (fr==cadena.length-1) {
                    fr = 0;
                }
                else{
                    fr += 1;
                }
            }
        }
        return temp;
    }
}
