/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colas;

/**
 *
 * @author danie
 */
public class Colas2 {
    public String[] nombre;
    public int fr;
    public int fi;
    
    Colas2(int n){
        this.nombre=new String[n];
        this.fr=-1;
        this.fi=-1;
}
    
    public void insertar(String nuevo){
        if (fi<nombre.length-1) {
            
            if (fr !=-1 && fi !=-1) {
                fi++;
                nombre[fi]=nuevo;
            }
            else{
                fr++;
                fi++;
                nombre[fi]=nuevo;
            }
        }else{
            System.out.println("No hay espacio");
        }
    
    }
    
    public String Eliminar(){
       String temp="";
        if (fr !=-1) {
            
            if (fr<(fi)) {
                temp = nombre[fr];
                nombre[fr]="";
                fr++;
            }else{
                temp = nombre[fr];
                fr=-1;
                fi=-1;
            }
        }
        else
            System.out.println("No hay elementos en la cola");
        return temp;
    }
}
