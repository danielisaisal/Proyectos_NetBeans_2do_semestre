/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colas;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class Colas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada=new Scanner(System.in);
        int n;
        n = entrada.nextInt();
        Colas2 col = new Colas2(n);
        System.out.println(col.Eliminar());
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.insertar("hugo");
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        System.out.println(col.Eliminar());
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.insertar("paco");
        col.insertar("luis");
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        System.out.println(col.Eliminar());
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        System.out.println(col.Eliminar());
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        col.insertar("Hola");
        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
        System.out.println(col.Eliminar());
       
    }
    
}
