/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colasnormalesycirculares;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class ColasNormalesyCirculares {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Metodos();
        
    }
    
    public static void Metodos(){
        Scanner entrada = new Scanner(System.in);
        int dec, n, decN, decC, decw=0;
        String datos;
        System.out.println("Ingrese el numero de metodo que quiera ver (0.Colas normales / 1.Colas circulares)");
        dec = entrada.nextInt();
        switch(dec){
            case 0:
                System.out.println("Ingrese el limite del arreglo");
                n = entrada.nextInt();
                ColasN col = new ColasN(n);
                do{
                System.out.println("Que quiere hacer (0.Insertar / 1.Eliminar)");
                decN = entrada.nextInt();
                switch(decN){
                    case 0:
                        System.out.println("Ingrese una cadena de letras");
                        datos = entrada.next();
                        col.insertar(datos);
                        System.out.println("Elemento ingresado: " + datos);
                        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
                        break;
                    case 1:
                        System.out.println("Elemento eliminado: " + col.Eliminar());
                        System.out.println("Frente: " + col.fr + "   Final:" + col.fi);
                        break;
                }
                System.out.println("¿Quiere terminar el proceso? (0.no / 1.si)");
                decw = entrada.nextInt();
                }while(decw !=1);
                break;
            case 1: 
                System.out.println("Ingrese el limite del arreglo");
                n = entrada.nextInt();
                ColasC colC = new ColasC(n);
                do{
                System.out.println("Que quiere hacer (0.Insertar / 1.Eliminar)");
                decN = entrada.nextInt();
                switch(decN){
                    case 0:
                        System.out.println("Ingrese una cadena de letras");
                        datos = entrada.next();
                        colC.Insertar(datos);
                        System.out.println("Elemento ingresado: " + datos);
                        System.out.println("Frente: " + colC.fr + "   Final:" + colC.fi);
                        break;
                    case 1:
                        System.out.println("Elemento eliminado: " + colC.Eliminar());
                        System.out.println("Frente: " + colC.fr + "   Final:" + colC.fi);
                        break;
                }
                System.out.println("¿Quiere terminar el proceso? (0.no / 1.si)");
                decw = entrada.nextInt();
                }while(decw !=1);
                break;
        }
    }
    
}
