/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package burbuja;
import java.util.Scanner;
/**
 *
 * @author danie
 */
public class Burbuja {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();
        Scanner entrada=new Scanner(System.in);
        int n;
        System.out.println("ingrese la cantidad de numeros a ordenar");
        n=entrada.nextInt();
        Ordenamiento objO=new Ordenamiento(n);
        objO.generarDatos();
          
        System.out.println("Elija el metodo con el que desea ordenar los datos");
        System.out.println("1 Metodo burbuja, 2 Metodo Insercion Directa, 3 Seleccion directa, 4 shaker sort");
          
        int metodo;
        metodo=entrada.nextInt();
         imprimir(objO,"Original");
        switch (metodo) {
            case 1:
                objO.burbujaOptimizado();
                imprimir(objO,"burbuja");
                
                break;
            case 2:
                objO.InsercionD();
                imprimir(objO,"Ordenado insercion directa");
                
                break;
            case 3:
                objO.seleccionDirecta();
                imprimir(objO,"Ordenado Seleccion directa");
                break;
            case 4:
                objO.shaker();
                imprimir(objO,"Ordenado Shaker");
                break;
            default:
                break;
        }
        
       // objO.burbuja();
       
        long finishTime = (System.currentTimeMillis()-startTime);
        System.out.println(finishTime);
    }
    
    public static void imprimir(Ordenamiento ob, String cadena){
        System.out.println("Arreglo: "+ cadena);
        for (int i = 0; i < ob.datos.length; i++) {
            System.out.print(ob.datos[i]+",");
        }
        System.out.println();
    }
    
    
}
