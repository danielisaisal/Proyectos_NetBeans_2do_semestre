/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package burbuja;

/**
 *
 * @author danie
 */
public class Ordenamiento {
    public int[] datos;
    
    public Ordenamiento(int n){
        datos=new int[n];
    }
    
    public void generarDatos(){
        for (int i = 0; i < datos.length; i++) {
            datos[i]=(int) (Math.random()*1000);
        }
    }
    
    public void burbuja(){
        int contComparaciones=0;
        for (int pasadas = 0; pasadas < datos.length-1; pasadas++) {
            
            for (int comparaciones = 0; comparaciones < datos.length-1; comparaciones++) {
                contComparaciones++;
                if (datos[comparaciones]>datos[comparaciones+1]) {
                    int aux=datos[comparaciones];
                    datos[comparaciones]=datos[comparaciones + 1];
                    datos[comparaciones+1]=aux;
                }
            }
        }
        System.out.println("Comparaciones: "+contComparaciones);
    }
    
     public void burbujaOptimizado(){
        int contComparaciones=0;
        for (int pasadas = 0; pasadas < datos.length-1; pasadas++) {
            
            for (int comparaciones = 0; comparaciones < datos.length-(pasadas+1); comparaciones++) {
                contComparaciones++;
                if (datos[comparaciones]>datos[comparaciones+1]) {
                    int aux=datos[comparaciones];
                    datos[comparaciones]=datos[comparaciones + 1];
                    datos[comparaciones+1]=aux;
                }
            }
        }
        System.out.println("Comparaciones: "+contComparaciones);
    }
    
     public void burbujaOptimizadoII(){
        int contComparaciones=0;
        for (int pasadas = 0; pasadas < datos.length-(pasadas+1); pasadas++) {
            
            for (int comparaciones = 0; comparaciones < datos.length-(pasadas+1); comparaciones++) {
                contComparaciones++;
                if (datos[comparaciones]>datos[comparaciones+1]) {
                    int aux=datos[comparaciones];
                    datos[comparaciones]=datos[comparaciones + 1];
                    datos[comparaciones+1]=aux;
                }
            }
        }
        System.out.println("Comparaciones: "+contComparaciones);
    }
     
    public void InsercionD(){
        int aux, contComparaciones=0;
        int p,j;
        for (p=1;p<datos.length;p++){
            contComparaciones++;
            aux=datos[p];
            j=p-1;
            while(j>=0 && aux<datos[j]){contComparaciones++;
                datos[j + 1]=datos[j];
                j--;
            }
            datos[j + 1]=aux;
        }
        System.out.println("Comparaciones: "+contComparaciones);
    }
     
     public void seleccionDirecta(){
         int menor, posicion, aux;
         int contComparaciones=0;
         for (int i = 0; i < datos.length; i++) {
             contComparaciones++;
             menor = datos[i];
             posicion = i;
             for (int j = i+1; j < datos.length; j++) {
                 if (datos[j] < menor) {
                     menor = datos[j];
                     posicion = j;
                 }
             }
             if (posicion !=i) {
                 aux = datos[i];
                 datos[i] = datos[posicion];
                 datos[posicion]=aux;
             }
         }
         System.out.println("Comparaciones: "+contComparaciones);
     
     }
     
     public void shaker(){
         int contComparaciones=0, contIntercambios=0, contPasadas=0;
        for (int pasadas = 0; pasadas < datos.length-1; pasadas++) {
            contPasadas++;
            for (int comparaciones = 0; comparaciones < datos.length-(pasadas+1); comparaciones++) {
                contComparaciones++;
                if (datos[comparaciones]>datos[comparaciones+1]) {
                    int aux=datos[comparaciones];
                    datos[comparaciones]=datos[comparaciones + 1];
                    datos[comparaciones+1]=aux;
                    contIntercambios++;
                }
            }
            for (int comparaciones = 0; comparaciones > 0+(pasadas+1); comparaciones--) {
                contComparaciones++;
                if (datos[comparaciones]>datos[comparaciones + 1]) {
                    int aux=datos[comparaciones];
                    datos[comparaciones]=datos[comparaciones + 1];
                    datos[comparaciones+1]=aux;
                    contIntercambios++;
                }
            }
        }
//        int contComparaciones=0, contIntercambios=0, contPasadas=0;
//        for (int pasadas = 0; pasadas < (datos.length-1)/2; pasadas++) {
//            contPasadas++;
//            for (int comparaciones = 0; comparaciones < datos.length-1; comparaciones++) {
//                contComparaciones++;
//                if (datos[comparaciones]>datos[comparaciones+1]) {
//                    int aux=datos[comparaciones];
//                    datos[comparaciones]=datos[comparaciones + 1];
//                    datos[comparaciones+1]=aux;
//                    contIntercambios++;
//                }
//            }
//            for (int comparaciones = datos.length-1; comparaciones > datos.length-1; comparaciones--) {
//                contComparaciones++;
//                if (datos[comparaciones]>datos[comparaciones - 1]) {
//                    int aux=datos[comparaciones];
//                    datos[comparaciones]=datos[comparaciones - 1];
//                    datos[comparaciones-1]=aux;
//                    contIntercambios++;
//                }
//            }
//        }
        System.out.println("Comparaciones: "+contComparaciones+" Intercambios: "+contIntercambios+" Pasadas"+contPasadas);
     }
}
